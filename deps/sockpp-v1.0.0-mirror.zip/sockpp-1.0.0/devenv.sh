#!/bin/sh
#
# Sets up the development environment for the sockpp library.
#

export SOCKPP_DIR=$PWD

export LD_LIBRARY_PATH=${SOCKPP_DIR}/lib

